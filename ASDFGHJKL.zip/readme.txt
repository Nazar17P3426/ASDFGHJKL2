ASDFGHJKL.exe
created by Hugopako

this Thallium at running ASDFGHJKL.exe

N   n ooooo
nn  n o     o
n  nn o     o
n   nn o    o
n    n ooooo

Ssssss k      iiii ddddd
s          k          d       d
ssssss k      iiii d       d
         s k kk iiii d       d
         s kk    iiii d       d
ssssss k kk iiii ddddd

GOOD MALWARE